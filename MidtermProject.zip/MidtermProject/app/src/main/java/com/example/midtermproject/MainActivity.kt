package com.example.midtermproject

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var aa = Game("divinity","98","rpg","d",null)
        var bb = Game("gtav","96","action","d",null)

        val games = arrayOf(
            aa,bb
        )
        var customAdapter = CustomAdapter(games)

        var myRecyclerView = findViewById<RecyclerView>(R.id.gamesList)

        myRecyclerView.adapter = customAdapter


    }
}